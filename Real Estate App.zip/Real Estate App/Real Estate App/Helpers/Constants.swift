//
//  Constants.swift
//  Real Estate App
//
//  Created by arifashraf on 13/12/21.
//

//import Foundation
//
//struct Constants {
//    
//    struct TextField {
//        static var personSymbol = "person"
//        static var passwordSymbol = "lock"
//    }
//    
//}
