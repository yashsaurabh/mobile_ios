//
//  Utilities.swift
//  Real Estate App
//
//  Created by arifashraf on 14/12/21.
//

//import SwiftUI
//
//struct Utilities {
//        
//    
//    
//}

