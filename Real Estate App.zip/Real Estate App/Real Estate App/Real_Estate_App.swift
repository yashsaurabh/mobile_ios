//
//  Real_Estate_AppApp.swift
//  Real Estate App
//
//  Created by arifashraf on 08/12/21.
//

import SwiftUI

@main
struct Real_Estate_App: App {
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}
