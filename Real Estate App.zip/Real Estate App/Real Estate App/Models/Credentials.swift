//
//  DummyModel.swift
//  Real Estate App
//
//  Created by arifashraf on 09/12/21.
//

import Foundation

struct Credentials {
    var username: String = "demo"
    var password: String = "demo"
}
