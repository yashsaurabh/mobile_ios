//
//  Deal+CoreDataClass.swift
//  Real Estate App
//
//  Created by ManishaThete on 03/01/22.
//
//

import Foundation
import CoreData

@objc(Deal)
public class Deal: NSManagedObject {

}
