//
//  User+CoreDataClass.swift
//  Real Estate App
//
//  Created by ManishaThete on 03/01/22.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
